//
//  Test.h
//  LKBinaryTest
//
//  Created by karos li on 2018/6/4.
//  Copyright © 2018年 lefit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Test : NSObject

+ (UIImage *)bundleImage;

+ (UIImage *)mainImage;

+ (NSInteger)addA:(NSInteger)a toB:(NSInteger)b;

@end
